/*
 * Extends jasmine expectations by defining new matchers
 */
var matchers = {
      isArray: function(){
         var s = typeof this.actual,
             result = false; 
         if (s === 'object'){
            if (this.actual){
               if (Object.prototype.toString.call(this.actual) === Object.prototype.toString.call([])) {
               alert('in');
                  result = true;
               }
            }
         }
         this.message = function(){
            if (result){
               return "Is Array";
            }
            return "Is not an Array";
         };
         return result;
      }
   };
   
/*beforeEach(function () {
   jasmine.addMatchers(matchers);
});*/
jasmine.Matchers.prototype.isArray = matchers.isArray;

beforeEach(function () {
  jasmine.addMatchers({
    toBePlaying: function () {
      return {
        compare: function (actual, expected) {
          var player = actual;

          return {
            pass: player.currentlyPlayingSong === expected && player.isPlaying
          }
        }
      };
    }
  });
});